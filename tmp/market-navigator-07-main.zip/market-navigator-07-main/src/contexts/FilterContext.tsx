import React, { createContext, useContext, useState, useCallback } from "react";

export interface FilterState {
  dealType: "sale" | "rent";
  timeRange: "7d" | "30d" | "90d";
  mapMode: "price" | "change" | "supply";
  hoveredRegion: string | null;
  selectedRegion: string | null;
}

interface FilterContextType {
  filters: FilterState;
  updateFilters: (updates: Partial<FilterState>) => void;
}

const defaultFilters: FilterState = {
  dealType: "sale",
  timeRange: "30d",
  mapMode: "price",
  hoveredRegion: null,
  selectedRegion: null,
};

const FilterContext = createContext<FilterContextType | undefined>(undefined);

export const FilterProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [filters, setFilters] = useState<FilterState>(defaultFilters);

  const updateFilters = useCallback((updates: Partial<FilterState>) => {
    setFilters((prev) => ({ ...prev, ...updates }));
  }, []);

  return (
    <FilterContext.Provider value={{ filters, updateFilters }}>
      {children}
    </FilterContext.Provider>
  );
};

export function useFilters() {
  const context = useContext(FilterContext);
  if (!context) {
    throw new Error("useFilters must be used within a FilterProvider");
  }
  return context;
}
