import { useMemo } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { useFilters } from "@/contexts/FilterContext";
import {
  priceDistributionSale,
  priceDistributionRent,
  CHART_COLORS,
} from "@/data/mockData";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  const data = payload[0]?.payload;
  return (
    <div className="bg-card/95 backdrop-blur-md border border-border rounded-lg p-2.5 shadow-xl">
      <p className="text-[11px] font-semibold mb-1">{label}</p>
      <div className="text-[11px] text-muted-foreground">
        <span className="font-mono font-medium text-foreground">
          {data?.count?.toLocaleString("pl-PL")}
        </span>{" "}
        listings ({data?.percentage}%)
      </div>
    </div>
  );
};

const PriceDistributionChart = () => {
  const { filters } = useFilters();

  const data = useMemo(
    () =>
      filters.dealType === "sale" ? priceDistributionSale : priceDistributionRent,
    [filters.dealType]
  );

  const maxCount = useMemo(() => Math.max(...data.map((d) => d.count)), [data]);

  return (
    <div
      className="bg-card border border-border rounded-lg p-3 animate-fade-in"
      style={{ animationDelay: "200ms" }}
    >
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
          Price Distribution
        </h3>
        <span className="text-[10px] text-muted-foreground font-mono">
          {filters.dealType === "sale" ? "PLN/m²" : "PLN/mo"}
        </span>
      </div>
      <div className="h-[140px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 5, right: 5, bottom: 0, left: -15 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={CHART_COLORS.grid} />
            <XAxis
              dataKey="range"
              stroke={CHART_COLORS.text}
              fontSize={8}
              tickLine={false}
              axisLine={false}
              fontFamily="JetBrains Mono"
              interval={0}
              angle={-35}
              textAnchor="end"
              height={30}
            />
            <YAxis
              stroke={CHART_COLORS.text}
              fontSize={9}
              tickLine={false}
              axisLine={false}
              fontFamily="JetBrains Mono"
              tickFormatter={(v) => `${(v / 1000).toFixed(1)}K`}
            />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
            <Bar dataKey="count" radius={[2, 2, 0, 0]} maxBarSize={24}>
              {data.map((entry, index) => {
                const t = entry.count / maxCount;
                return (
                  <Cell
                    key={`cell-${index}`}
                    fill={`rgba(43, 181, 160, ${0.25 + t * 0.55})`}
                  />
                );
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default PriceDistributionChart;
