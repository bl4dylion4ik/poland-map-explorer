import { useMemo } from "react";
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useFilters } from "@/contexts/FilterContext";
import { generateTimeSeries, CHART_COLORS } from "@/data/mockData";

const timeRangeToDays = (range: string) => {
  switch (range) {
    case "7d": return 7;
    case "30d": return 30;
    case "90d": return 90;
    default: return 30;
  }
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card/95 backdrop-blur-md border border-border rounded-lg p-2.5 shadow-xl">
      <p className="text-[10px] text-muted-foreground font-mono mb-1.5">{label}</p>
      {payload.map((entry: any, i: number) => (
        <div key={i} className="flex items-center gap-2 text-[11px]">
          <span
            className="w-2 h-2 rounded-full"
            style={{ background: entry.color }}
          />
          <span className="text-muted-foreground">{entry.name}</span>
          <span className="font-mono font-medium ml-auto">
            {typeof entry.value === "number"
              ? entry.value.toLocaleString("pl-PL")
              : entry.value}
          </span>
        </div>
      ))}
    </div>
  );
};

const SupplyChart = () => {
  const { filters } = useFilters();

  const data = useMemo(
    () => generateTimeSeries(timeRangeToDays(filters.timeRange)),
    [filters.timeRange]
  );

  const formatDate = (date: string) => {
    const d = new Date(date);
    return `${d.getDate()}/${d.getMonth() + 1}`;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-3 animate-fade-in" style={{ animationDelay: "100ms" }}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
          Supply Dynamics
        </h3>
        <div className="flex items-center gap-3 text-[9px] font-mono">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-sm" style={{ background: CHART_COLORS.muted }} />
            Active
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-0.5 rounded-full" style={{ background: CHART_COLORS.positive }} />
            New
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-0.5 rounded-full" style={{ background: CHART_COLORS.negative }} />
            Removed
          </span>
        </div>
      </div>
      <div className="h-[160px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 5, right: 5, bottom: 0, left: -15 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={CHART_COLORS.grid} />
            <XAxis
              dataKey="date"
              tickFormatter={formatDate}
              stroke={CHART_COLORS.text}
              fontSize={9}
              tickLine={false}
              axisLine={false}
              interval="preserveStartEnd"
              fontFamily="JetBrains Mono"
            />
            <YAxis
              yAxisId="left"
              stroke={CHART_COLORS.text}
              fontSize={9}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`}
              fontFamily="JetBrains Mono"
            />
            <YAxis
              yAxisId="right"
              orientation="right"
              stroke={CHART_COLORS.text}
              fontSize={9}
              tickLine={false}
              axisLine={false}
              fontFamily="JetBrains Mono"
              hide
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar
              yAxisId="left"
              dataKey="activeListings"
              fill={CHART_COLORS.muted}
              opacity={0.3}
              name="Active"
              radius={[1, 1, 0, 0]}
            />
            <Line
              yAxisId="right"
              dataKey="newListings"
              stroke={CHART_COLORS.positive}
              strokeWidth={1.5}
              dot={false}
              name="New"
              type="monotone"
            />
            <Line
              yAxisId="right"
              dataKey="removedListings"
              stroke={CHART_COLORS.negative}
              strokeWidth={1.5}
              dot={false}
              name="Removed"
              type="monotone"
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default SupplyChart;
