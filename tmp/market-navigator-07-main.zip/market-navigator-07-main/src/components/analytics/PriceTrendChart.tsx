import { useMemo } from "react";
import {
  ComposedChart,
  Line,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useFilters } from "@/contexts/FilterContext";
import { generateTimeSeries, CHART_COLORS } from "@/data/mockData";

const timeRangeToDays = (range: string) => {
  switch (range) {
    case "7d": return 7;
    case "30d": return 30;
    case "90d": return 90;
    default: return 30;
  }
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card/95 backdrop-blur-md border border-border rounded-lg p-2.5 shadow-xl">
      <p className="text-[10px] text-muted-foreground font-mono mb-1.5">{label}</p>
      {payload.map((entry: any, i: number) => (
        <div key={i} className="flex items-center gap-2 text-[11px]">
          <span
            className="w-2 h-2 rounded-full"
            style={{ background: entry.color }}
          />
          <span className="text-muted-foreground">{entry.name}</span>
          <span className="font-mono font-medium ml-auto">
            {typeof entry.value === "number"
              ? entry.value.toLocaleString("pl-PL")
              : entry.value}
          </span>
        </div>
      ))}
    </div>
  );
};

const PriceTrendChart = () => {
  const { filters } = useFilters();

  const data = useMemo(
    () => generateTimeSeries(timeRangeToDays(filters.timeRange)),
    [filters.timeRange]
  );

  const formatDate = (date: string) => {
    const d = new Date(date);
    return `${d.getDate()}/${d.getMonth() + 1}`;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-3 animate-fade-in">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
          Price Trend
        </h3>
        <span className="text-[10px] text-muted-foreground font-mono">
          {filters.dealType === "sale" ? "PLN/m²" : "PLN/mo"}
        </span>
      </div>
      <div className="h-[180px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 5, right: 5, bottom: 0, left: -15 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={CHART_COLORS.grid} />
            <XAxis
              dataKey="date"
              tickFormatter={formatDate}
              stroke={CHART_COLORS.text}
              fontSize={9}
              tickLine={false}
              axisLine={false}
              interval="preserveStartEnd"
              fontFamily="JetBrains Mono"
            />
            <YAxis
              stroke={CHART_COLORS.text}
              fontSize={9}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`}
              fontFamily="JetBrains Mono"
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              dataKey="p75"
              stroke="none"
              fill={CHART_COLORS.areaBand}
              name="P75"
              type="monotone"
            />
            <Area
              dataKey="p25"
              stroke="none"
              fill="hsl(225, 35%, 11%)"
              name="P25"
              type="monotone"
            />
            <Line
              dataKey="medianPrice"
              stroke={CHART_COLORS.primary}
              strokeWidth={2}
              dot={false}
              name="Median"
              type="monotone"
            />
            <Line
              dataKey="avgPrice"
              stroke={CHART_COLORS.secondary}
              strokeWidth={1.5}
              strokeDasharray="4 3"
              dot={false}
              name="Average"
              type="monotone"
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default PriceTrendChart;
