import { useFilters } from "@/contexts/FilterContext";
import { cn } from "@/lib/utils";
import { Activity, TrendingUp, Layers } from "lucide-react";

const GlobalFilters = () => {
  const { filters, updateFilters } = useFilters();

  return (
    <header className="h-12 border-b border-border bg-card/60 backdrop-blur-sm flex items-center px-4 gap-3 flex-shrink-0 z-20">
      {/* Brand */}
      <div className="flex items-center gap-2 mr-2">
        <Activity className="h-4 w-4 text-primary" />
        <span className="font-display font-semibold text-sm tracking-tight">
          PUL<span className="text-primary">SE</span>
        </span>
      </div>

      <div className="w-px h-6 bg-border" />

      {/* Deal Type Toggle */}
      <div className="flex bg-muted/50 rounded-md p-0.5 gap-0.5">
        {(["sale", "rent"] as const).map((type) => (
          <button
            key={type}
            onClick={() => updateFilters({ dealType: type })}
            className={cn(
              "px-3 py-1 text-[11px] font-semibold uppercase tracking-wider rounded-sm transition-all duration-200",
              filters.dealType === type
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            {type}
          </button>
        ))}
      </div>

      <div className="w-px h-6 bg-border" />

      {/* Map Mode */}
      <div className="flex items-center gap-1">
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider mr-1">Map</span>
        <div className="flex bg-muted/50 rounded-md p-0.5 gap-0.5">
          {([
            { key: "price" as const, label: "Price", icon: null },
            { key: "change" as const, label: "Δ 30d", icon: null },
            { key: "supply" as const, label: "Supply", icon: null },
          ]).map(({ key, label }) => (
            <button
              key={key}
              onClick={() => updateFilters({ mapMode: key })}
              className={cn(
                "px-2.5 py-1 text-[11px] font-medium rounded-sm transition-all duration-200",
                filters.mapMode === key
                  ? "bg-secondary text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Selected Region Indicator */}
      {filters.selectedRegion && (
        <div className="flex items-center gap-2 px-3 py-1 bg-primary/10 border border-primary/20 rounded-md">
          <span className="text-[11px] font-medium text-primary">
            {filters.selectedRegion}
          </span>
          <button
            onClick={() => updateFilters({ selectedRegion: null })}
            className="text-primary/60 hover:text-primary text-xs"
          >
            ✕
          </button>
        </div>
      )}

      {/* Time Range */}
      <div className="flex items-center gap-1">
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider mr-1">Period</span>
        <div className="flex bg-muted/50 rounded-md p-0.5 gap-0.5">
          {(["7d", "30d", "90d"] as const).map((range) => (
            <button
              key={range}
              onClick={() => updateFilters({ timeRange: range })}
              className={cn(
                "px-2.5 py-1 text-[11px] font-mono font-medium rounded-sm transition-all duration-200",
                filters.timeRange === range
                  ? "bg-secondary text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {range.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Live Indicator */}
      <div className="flex items-center gap-1.5 ml-2">
        <span className="h-1.5 w-1.5 rounded-full bg-chart-positive animate-pulse-dot" />
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Live</span>
      </div>
    </header>
  );
};

export default GlobalFilters;
