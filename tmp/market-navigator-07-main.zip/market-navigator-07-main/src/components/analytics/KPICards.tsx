import { useMemo } from "react";
import { useFilters } from "@/contexts/FilterContext";
import { getKPIs } from "@/data/mockData";
import { TrendingUp, TrendingDown, Building2, Plus, Minus, BarChart3, Target, Percent } from "lucide-react";
import { cn } from "@/lib/utils";

interface KPICardProps {
  label: string;
  value: string;
  change?: number;
  icon: React.ReactNode;
  delay?: number;
}

const KPICard = ({ label, value, change, icon, delay = 0 }: KPICardProps) => (
  <div
    className="bg-card border border-border rounded-lg p-3 animate-fade-in"
    style={{ animationDelay: `${delay}ms` }}
  >
    <div className="flex items-center justify-between mb-1.5">
      <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider">
        {label}
      </span>
      <span className="text-muted-foreground">{icon}</span>
    </div>
    <div className="font-mono text-lg font-semibold tracking-tight leading-none mb-1">
      {value}
    </div>
    {change !== undefined && (
      <div className={cn("flex items-center gap-1 text-[11px] font-mono font-medium", change >= 0 ? "text-positive" : "text-negative")}>
        {change >= 0 ? (
          <TrendingUp className="h-3 w-3" />
        ) : (
          <TrendingDown className="h-3 w-3" />
        )}
        {change >= 0 ? "+" : ""}
        {change}%
      </div>
    )}
  </div>
);

const KPICards = () => {
  const { filters } = useFilters();

  const kpis = useMemo(() => getKPIs(filters.dealType), [filters.dealType]);

  const formatNumber = (n: number) => n.toLocaleString("pl-PL");
  const formatPrice = (n: number) =>
    filters.dealType === "sale"
      ? `${formatNumber(n)} PLN/m²`
      : `${formatNumber(n)} PLN/mo`;

  return (
    <div className="grid grid-cols-3 gap-2 p-3">
      <KPICard
        label="Active Listings"
        value={formatNumber(kpis.totalListings)}
        change={2.3}
        icon={<Building2 className="h-3.5 w-3.5" />}
        delay={0}
      />
      <KPICard
        label="New (7d)"
        value={formatNumber(kpis.totalNew7d)}
        change={5.1}
        icon={<Plus className="h-3.5 w-3.5" />}
        delay={50}
      />
      <KPICard
        label="Removed (7d)"
        value={formatNumber(kpis.totalRemoved7d)}
        change={-1.8}
        icon={<Minus className="h-3.5 w-3.5" />}
        delay={100}
      />
      <KPICard
        label="Median Price"
        value={formatPrice(kpis.avgMedianPrice)}
        change={kpis.avgChange}
        icon={<BarChart3 className="h-3.5 w-3.5" />}
        delay={150}
      />
      <KPICard
        label="MoM Change"
        value={`${kpis.avgChange >= 0 ? "+" : ""}${kpis.avgChange}%`}
        icon={<Percent className="h-3.5 w-3.5" />}
        delay={200}
      />
      <KPICard
        label="Avg Yield"
        value={`${kpis.avgYield}%`}
        icon={<Target className="h-3.5 w-3.5" />}
        delay={250}
      />
    </div>
  );
};

export default KPICards;
