import { useState, useMemo, useCallback, useEffect } from "react";
import { useFilters } from "@/contexts/FilterContext";
import { getVoivodeshipGeoJSON, cities, voivodeships } from "@/data/mockData";
import Map from "react-map-gl/maplibre";
import DeckGL from "@deck.gl/react";
import { GeoJsonLayer, ScatterplotLayer } from "@deck.gl/layers";
import type { PickingInfo, MapViewState } from "@deck.gl/core";

const INITIAL_VIEW_STATE: MapViewState = {
  longitude: 19.4,
  latitude: 52.0,
  zoom: 5.6,
  pitch: 0,
  bearing: 0,
};

const MAP_STYLE = "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json";

// Color scales
function priceToColor(price: number, min: number, max: number): [number, number, number, number] {
  const t = Math.max(0, Math.min(1, (price - min) / (max - min)));
  if (t < 0.5) {
    const s = t * 2;
    return [
      Math.round(15 + s * 28),
      Math.round(35 + s * 122),
      Math.round(90 + s * 53),
      180,
    ];
  }
  const s = (t - 0.5) * 2;
  return [
    Math.round(43 + s * 202),
    Math.round(157 - s * 2),
    Math.round(143 - s * 132),
    200,
  ];
}

function changeToColor(change: number): [number, number, number, number] {
  if (change > 0) {
    const t = Math.min(1, change / 4);
    return [34 + Math.round(t * 10), Math.round(180 + t * 31), Math.round(120 + t * 30), 200];
  }
  const t = Math.min(1, Math.abs(change) / 4);
  return [Math.round(200 + t * 48), Math.round(80 - t * 30), Math.round(80 - t * 30), 200];
}

function supplyToColor(listings: number, max: number): [number, number, number, number] {
  const t = Math.min(1, listings / max);
  return [
    Math.round(30 + t * 90),
    Math.round(50 + t * 80),
    Math.round(140 + t * 60),
    Math.round(120 + t * 80),
  ];
}

interface HoverInfo {
  x: number;
  y: number;
  name: string;
  medianPrice: number;
  listings: number;
  change30d: number;
  medianRent: number;
}

const MapView = () => {
  const { filters, updateFilters } = useFilters();
  const [hoverInfo, setHoverInfo] = useState<HoverInfo | null>(null);
  const [viewState, setViewState] = useState(INITIAL_VIEW_STATE);

  const geojson = useMemo(() => getVoivodeshipGeoJSON(), []);
  const priceRange = useMemo(() => {
    const prices = voivodeships.map((v) => v.medianPrice);
    return { min: Math.min(...prices), max: Math.max(...prices) };
  }, []);
  const maxListings = useMemo(() => Math.max(...voivodeships.map((v) => v.listings)), []);

  const getFillColor = useCallback(
    (d: any): [number, number, number, number] => {
      const props = d.properties;
      if (filters.selectedRegion && props.name !== filters.selectedRegion) {
        return [30, 35, 50, 80];
      }
      if (filters.hoveredRegion && props.name === filters.hoveredRegion) {
        // Brighten hovered region
        const base =
          filters.mapMode === "price"
            ? priceToColor(props.medianPrice, priceRange.min, priceRange.max)
            : filters.mapMode === "change"
            ? changeToColor(props.change30d)
            : supplyToColor(props.listings, maxListings);
        return [
          Math.min(255, base[0] + 40),
          Math.min(255, base[1] + 40),
          Math.min(255, base[2] + 40),
          220,
        ];
      }
      switch (filters.mapMode) {
        case "price":
          return priceToColor(props.medianPrice, priceRange.min, priceRange.max);
        case "change":
          return changeToColor(props.change30d);
        case "supply":
          return supplyToColor(props.listings, maxListings);
        default:
          return priceToColor(props.medianPrice, priceRange.min, priceRange.max);
      }
    },
    [filters.mapMode, filters.hoveredRegion, filters.selectedRegion, priceRange, maxListings]
  );

  const layers = useMemo(
    () => [
      new GeoJsonLayer({
        id: "voivodeships",
        data: geojson as any,
        filled: true,
        stroked: true,
        getFillColor: getFillColor as any,
        getLineColor: [100, 120, 160, 60],
        getLineWidth: 1,
        lineWidthMinPixels: 1,
        pickable: true,
        autoHighlight: true,
        highlightColor: [255, 255, 255, 30],
        updateTriggers: {
          getFillColor: [filters.mapMode, filters.hoveredRegion, filters.selectedRegion],
        },
        transitions: {
          getFillColor: { duration: 300, type: "interpolation" },
        },
      }),
      new ScatterplotLayer({
        id: "cities",
        data: cities,
        getPosition: (d: any) => d.coordinates,
        getRadius: (d: any) => Math.sqrt(d.listings) * 120,
        getFillColor: (d: any) =>
          d.change30d > 0
            ? [34, 211, 153, 160]
            : d.change30d < 0
            ? [248, 113, 113, 160]
            : [148, 163, 184, 120],
        getLineColor: [255, 255, 255, 40],
        lineWidthMinPixels: 1,
        stroked: true,
        pickable: true,
        radiusMinPixels: 4,
        radiusMaxPixels: 40,
      }),
    ],
    [geojson, getFillColor, filters.mapMode, filters.hoveredRegion, filters.selectedRegion]
  );

  const onHover = useCallback(
    (info: PickingInfo) => {
      if (info.object && info.layer?.id === "voivodeships") {
        const props = info.object.properties;
        setHoverInfo({
          x: info.x ?? 0,
          y: info.y ?? 0,
          name: props.name,
          medianPrice: props.medianPrice,
          listings: props.listings,
          change30d: props.change30d,
          medianRent: props.medianRent,
        });
        updateFilters({ hoveredRegion: props.name });
      } else if (info.object && info.layer?.id === "cities") {
        const city = info.object as any;
        setHoverInfo({
          x: info.x ?? 0,
          y: info.y ?? 0,
          name: city.name,
          medianPrice: city.medianPrice,
          listings: city.listings,
          change30d: city.change30d,
          medianRent: city.medianRent,
        });
      } else {
        setHoverInfo(null);
        if (filters.hoveredRegion) {
          updateFilters({ hoveredRegion: null });
        }
      }
    },
    [updateFilters, filters.hoveredRegion]
  );

  const onClick = useCallback(
    (info: PickingInfo) => {
      if (info.object && info.layer?.id === "voivodeships") {
        const name = info.object.properties.name;
        updateFilters({
          selectedRegion: filters.selectedRegion === name ? null : name,
        });
      }
    },
    [updateFilters, filters.selectedRegion]
  );

  return (
    <div className="w-full h-full relative">
      <DeckGL
        viewState={viewState}
        onViewStateChange={({ viewState: vs }: any) => setViewState(vs)}
        controller={true}
        layers={layers}
        onHover={onHover}
        onClick={onClick}
        getCursor={({ isHovering }: { isHovering: boolean }) =>
          isHovering ? "pointer" : "grab"
        }
      >
        <Map mapStyle={MAP_STYLE} />
      </DeckGL>

      {/* Tooltip */}
      {hoverInfo && (
        <div
          className="absolute z-30 pointer-events-none bg-card/95 backdrop-blur-md border border-border rounded-lg p-3 shadow-xl min-w-[180px]"
          style={{
            left: hoverInfo.x + 12,
            top: hoverInfo.y - 10,
          }}
        >
          <div className="font-semibold text-sm mb-1.5">{hoverInfo.name}</div>
          <div className="space-y-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-muted-foreground">Median price</span>
              <span className="font-mono font-medium">
                {hoverInfo.medianPrice.toLocaleString("pl-PL")} PLN/m²
              </span>
            </div>
            <div className="flex justify-between text-[11px]">
              <span className="text-muted-foreground">Median rent</span>
              <span className="font-mono font-medium">
                {hoverInfo.medianRent.toLocaleString("pl-PL")} PLN/mo
              </span>
            </div>
            <div className="flex justify-between text-[11px]">
              <span className="text-muted-foreground">Listings</span>
              <span className="font-mono font-medium">
                {hoverInfo.listings.toLocaleString("pl-PL")}
              </span>
            </div>
            <div className="flex justify-between text-[11px]">
              <span className="text-muted-foreground">30d change</span>
              <span
                className={`font-mono font-medium ${
                  hoverInfo.change30d >= 0 ? "text-positive" : "text-negative"
                }`}
              >
                {hoverInfo.change30d >= 0 ? "+" : ""}
                {hoverInfo.change30d}%
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Map Legend */}
      <div className="absolute bottom-4 left-4 z-20 bg-card/90 backdrop-blur-md border border-border rounded-lg p-3">
        <div className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-2">
          {filters.mapMode === "price"
            ? "Median Price (PLN/m²)"
            : filters.mapMode === "change"
            ? "30-Day Change (%)"
            : "Active Listings"}
        </div>
        {filters.mapMode === "price" && (
          <div className="flex items-center gap-1">
            <span className="text-[9px] font-mono text-muted-foreground">5K</span>
            <div className="flex h-2 flex-1 rounded-sm overflow-hidden">
              <div className="flex-1" style={{ background: "rgb(15, 35, 90)" }} />
              <div className="flex-1" style={{ background: "rgb(29, 96, 116)" }} />
              <div className="flex-1" style={{ background: "rgb(43, 157, 143)" }} />
              <div className="flex-1" style={{ background: "rgb(144, 158, 76)" }} />
              <div className="flex-1" style={{ background: "rgb(245, 158, 11)" }} />
            </div>
            <span className="text-[9px] font-mono text-muted-foreground">16K+</span>
          </div>
        )}
        {filters.mapMode === "change" && (
          <div className="flex items-center gap-1">
            <span className="text-[9px] font-mono text-negative">-4%</span>
            <div className="flex h-2 flex-1 rounded-sm overflow-hidden">
              <div className="flex-1" style={{ background: "rgb(248, 113, 113)" }} />
              <div className="flex-1" style={{ background: "rgb(180, 120, 100)" }} />
              <div className="flex-1" style={{ background: "rgb(120, 140, 120)" }} />
              <div className="flex-1" style={{ background: "rgb(80, 180, 140)" }} />
              <div className="flex-1" style={{ background: "rgb(34, 211, 153)" }} />
            </div>
            <span className="text-[9px] font-mono text-positive">+4%</span>
          </div>
        )}
        {filters.mapMode === "supply" && (
          <div className="flex items-center gap-1">
            <span className="text-[9px] font-mono text-muted-foreground">Low</span>
            <div className="flex h-2 flex-1 rounded-sm overflow-hidden">
              <div className="flex-1" style={{ background: "rgb(30, 50, 140)" }} />
              <div className="flex-1" style={{ background: "rgb(60, 80, 160)" }} />
              <div className="flex-1" style={{ background: "rgb(90, 110, 180)" }} />
              <div className="flex-1" style={{ background: "rgb(120, 130, 200)" }} />
            </div>
            <span className="text-[9px] font-mono text-muted-foreground">High</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default MapView;
