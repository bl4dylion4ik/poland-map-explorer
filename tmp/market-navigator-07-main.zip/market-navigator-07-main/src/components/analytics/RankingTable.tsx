import { useMemo, useState } from "react";
import { useFilters } from "@/contexts/FilterContext";
import { getRankings, type RankingEntry } from "@/data/mockData";
import { cn } from "@/lib/utils";
import { ChevronUp, ChevronDown } from "lucide-react";

type SortKey = keyof RankingEntry;

const RankingTable = () => {
  const { filters, updateFilters } = useFilters();
  const [sortKey, setSortKey] = useState<SortKey>("change30d");
  const [sortAsc, setSortAsc] = useState(false);

  const data = useMemo(() => {
    const rankings = getRankings(filters.dealType);
    return [...rankings].sort((a, b) => {
      const va = a[sortKey];
      const vb = b[sortKey];
      if (typeof va === "number" && typeof vb === "number") {
        return sortAsc ? va - vb : vb - va;
      }
      return sortAsc
        ? String(va).localeCompare(String(vb))
        : String(vb).localeCompare(String(va));
    });
  }, [filters.dealType, sortKey, sortAsc]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortAsc(!sortAsc);
    } else {
      setSortKey(key);
      setSortAsc(false);
    }
  };

  const SortIcon = ({ column }: { column: SortKey }) => {
    if (sortKey !== column) return null;
    return sortAsc ? (
      <ChevronUp className="h-3 w-3" />
    ) : (
      <ChevronDown className="h-3 w-3" />
    );
  };

  const columns: { key: SortKey; label: string; format: (v: any) => string; align?: string }[] = [
    { key: "region", label: "Region", format: (v) => v },
    {
      key: "medianPrice",
      label: filters.dealType === "sale" ? "Price" : "Rent",
      format: (v) => v.toLocaleString("pl-PL"),
      align: "right",
    },
    {
      key: "change30d",
      label: "Δ 30d",
      format: (v) => `${v >= 0 ? "+" : ""}${v}%`,
      align: "right",
    },
    {
      key: "listings",
      label: "Listings",
      format: (v) => v.toLocaleString("pl-PL"),
      align: "right",
    },
    {
      key: "yield",
      label: "Yield",
      format: (v) => `${v}%`,
      align: "right",
    },
  ];

  return (
    <div
      className="bg-card border border-border rounded-lg p-3 animate-fade-in"
      style={{ animationDelay: "300ms" }}
    >
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
          Regional Ranking
        </h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-[11px]">
          <thead>
            <tr className="border-b border-border">
              {columns.map((col) => (
                <th
                  key={col.key}
                  className={cn(
                    "py-1.5 px-1.5 font-medium text-muted-foreground cursor-pointer hover:text-foreground transition-colors",
                    col.align === "right" ? "text-right" : "text-left"
                  )}
                  onClick={() => toggleSort(col.key)}
                >
                  <span className="inline-flex items-center gap-0.5">
                    {col.label}
                    <SortIcon column={col.key} />
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, idx) => (
              <tr
                key={row.region}
                className={cn(
                  "border-b border-border/50 transition-colors cursor-pointer",
                  filters.hoveredRegion === row.region && "bg-primary/5",
                  filters.selectedRegion === row.region && "bg-primary/10"
                )}
                onMouseEnter={() => updateFilters({ hoveredRegion: row.region })}
                onMouseLeave={() => updateFilters({ hoveredRegion: null })}
                onClick={() =>
                  updateFilters({
                    selectedRegion:
                      filters.selectedRegion === row.region ? null : row.region,
                  })
                }
              >
                {columns.map((col) => (
                  <td
                    key={col.key}
                    className={cn(
                      "py-1.5 px-1.5 font-mono",
                      col.align === "right" ? "text-right" : "text-left",
                      col.key === "change30d" &&
                        (row.change30d >= 0 ? "text-positive" : "text-negative"),
                      col.key === "region" && "font-sans font-medium"
                    )}
                  >
                    {col.format(row[col.key])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RankingTable;
