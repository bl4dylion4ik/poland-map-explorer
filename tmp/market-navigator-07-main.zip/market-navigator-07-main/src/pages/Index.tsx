import { FilterProvider } from "@/contexts/FilterContext";
import GlobalFilters from "@/components/analytics/GlobalFilters";
import KPICards from "@/components/analytics/KPICards";
import MapView from "@/components/analytics/MapView";
import PriceTrendChart from "@/components/analytics/PriceTrendChart";
import SupplyChart from "@/components/analytics/SupplyChart";
import PriceDistributionChart from "@/components/analytics/PriceDistributionChart";
import RankingTable from "@/components/analytics/RankingTable";

const Index = () => {
  return (
    <FilterProvider>
      <div className="h-screen flex flex-col bg-background text-foreground overflow-hidden">
        {/* Global Filter Bar */}
        <GlobalFilters />

        {/* Main Content: Analytics Panel + Map */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left: Analytics Panel */}
          <aside className="w-[400px] xl:w-[440px] flex-shrink-0 border-r border-border overflow-y-auto analytics-scroll">
            <KPICards />
            <div className="space-y-2.5 px-3 pb-4">
              <PriceTrendChart />
              <SupplyChart />
              <PriceDistributionChart />
              <RankingTable />
            </div>
          </aside>

          {/* Right: Interactive Map */}
          <main className="flex-1 relative">
            <MapView />
          </main>
        </div>
      </div>
    </FilterProvider>
  );
};

export default Index;
