// ===== Types =====

export interface VoivodeshipData {
  id: string;
  name: string;
  center: [number, number];
  radius: number;
  medianPrice: number;
  avgPrice: number;
  listings: number;
  newListings7d: number;
  removedListings7d: number;
  change30d: number;
  volatility: number;
  yieldEstimate: number;
  riskScore: number;
  medianRent: number;
}

export interface CityData {
  name: string;
  coordinates: [number, number];
  listings: number;
  medianPrice: number;
  change30d: number;
  voivodeship: string;
  medianRent: number;
}

export interface TimeSeriesPoint {
  date: string;
  medianPrice: number;
  avgPrice: number;
  p25: number;
  p75: number;
  activeListings: number;
  newListings: number;
  removedListings: number;
  priceChangePct: number;
}

export interface PriceBucket {
  range: string;
  count: number;
  percentage: number;
  minPrice: number;
}

export interface RankingEntry {
  region: string;
  medianPrice: number;
  change30d: number;
  listings: number;
  volatility: number;
  yield: number;
}

// ===== Voivodeships =====

export const voivodeships: VoivodeshipData[] = [
  { id: "mazowieckie", name: "Mazowieckie", center: [20.6, 52.2], radius: 1.15, medianPrice: 14500, avgPrice: 15800, listings: 8500, newListings7d: 1240, removedListings7d: 980, change30d: 3.2, volatility: 2.1, yieldEstimate: 4.8, riskScore: 12, medianRent: 3800 },
  { id: "malopolskie", name: "Małopolskie", center: [20.05, 49.85], radius: 0.85, medianPrice: 11200, avgPrice: 12100, listings: 4200, newListings7d: 580, removedListings7d: 520, change30d: 2.1, volatility: 1.8, yieldEstimate: 5.2, riskScore: 8, medianRent: 2900 },
  { id: "wielkopolskie", name: "Wielkopolskie", center: [17.1, 52.1], radius: 1.1, medianPrice: 8900, avgPrice: 9400, listings: 3800, newListings7d: 490, removedListings7d: 430, change30d: 1.5, volatility: 1.2, yieldEstimate: 5.8, riskScore: 6, medianRent: 2200 },
  { id: "dolnoslaskie", name: "Dolnośląskie", center: [16.5, 51.1], radius: 0.95, medianPrice: 9800, avgPrice: 10500, listings: 3600, newListings7d: 460, removedListings7d: 410, change30d: 1.8, volatility: 1.5, yieldEstimate: 5.5, riskScore: 7, medianRent: 2500 },
  { id: "slaskie", name: "Śląskie", center: [19.05, 50.3], radius: 0.65, medianPrice: 7200, avgPrice: 7800, listings: 3200, newListings7d: 420, removedListings7d: 380, change30d: -0.5, volatility: 2.4, yieldEstimate: 6.2, riskScore: 15, medianRent: 1900 },
  { id: "pomorskie", name: "Pomorskie", center: [18.2, 54.25], radius: 0.9, medianPrice: 11800, avgPrice: 12500, listings: 3500, newListings7d: 510, removedListings7d: 460, change30d: 2.8, volatility: 1.6, yieldEstimate: 4.9, riskScore: 9, medianRent: 3200 },
  { id: "lodzkie", name: "Łódzkie", center: [19.6, 51.7], radius: 0.85, medianPrice: 6800, avgPrice: 7200, listings: 2800, newListings7d: 340, removedListings7d: 310, change30d: 0.8, volatility: 1.9, yieldEstimate: 6.5, riskScore: 11, medianRent: 1800 },
  { id: "lubelskie", name: "Lubelskie", center: [22.8, 51.25], radius: 1.0, medianPrice: 6200, avgPrice: 6600, listings: 2100, newListings7d: 260, removedListings7d: 240, change30d: 0.4, volatility: 1.1, yieldEstimate: 6.8, riskScore: 5, medianRent: 1600 },
  { id: "podkarpackie", name: "Podkarpackie", center: [22.0, 49.85], radius: 0.88, medianPrice: 5800, avgPrice: 6100, listings: 1800, newListings7d: 210, removedListings7d: 190, change30d: -0.2, volatility: 0.9, yieldEstimate: 7.1, riskScore: 4, medianRent: 1500 },
  { id: "kujawsko_pomorskie", name: "Kujawsko-Pomorskie", center: [18.55, 53.15], radius: 0.8, medianPrice: 6500, avgPrice: 6900, listings: 2200, newListings7d: 280, removedListings7d: 260, change30d: 1.0, volatility: 1.3, yieldEstimate: 6.4, riskScore: 7, medianRent: 1700 },
  { id: "zachodniopomorskie", name: "Zachodniopomorskie", center: [15.6, 53.75], radius: 1.05, medianPrice: 7800, avgPrice: 8200, listings: 2600, newListings7d: 320, removedListings7d: 290, change30d: 1.2, volatility: 1.4, yieldEstimate: 5.9, riskScore: 8, medianRent: 2000 },
  { id: "warminsko_mazurskie", name: "Warmińsko-Mazurskie", center: [20.6, 53.85], radius: 1.05, medianPrice: 5500, avgPrice: 5900, listings: 1600, newListings7d: 190, removedListings7d: 170, change30d: 0.6, volatility: 0.8, yieldEstimate: 7.3, riskScore: 3, medianRent: 1400 },
  { id: "podlaskie", name: "Podlaskie", center: [23.0, 53.4], radius: 0.9, medianPrice: 6000, avgPrice: 6400, listings: 1400, newListings7d: 170, removedListings7d: 150, change30d: 0.3, volatility: 0.7, yieldEstimate: 7.0, riskScore: 3, medianRent: 1550 },
  { id: "lubuskie", name: "Lubuskie", center: [15.55, 52.0], radius: 0.72, medianPrice: 5900, avgPrice: 6200, listings: 1200, newListings7d: 140, removedListings7d: 130, change30d: 0.7, volatility: 1.0, yieldEstimate: 7.2, riskScore: 4, medianRent: 1450 },
  { id: "swietokrzyskie", name: "Świętokrzyskie", center: [20.7, 50.85], radius: 0.6, medianPrice: 5400, avgPrice: 5700, listings: 1100, newListings7d: 130, removedListings7d: 120, change30d: -0.3, volatility: 1.1, yieldEstimate: 7.5, riskScore: 5, medianRent: 1350 },
  { id: "opolskie", name: "Opolskie", center: [17.9, 50.7], radius: 0.58, medianPrice: 5600, avgPrice: 5900, listings: 950, newListings7d: 110, removedListings7d: 100, change30d: 0.1, volatility: 0.9, yieldEstimate: 7.4, riskScore: 4, medianRent: 1380 },
];

// ===== Cities =====

export const cities: CityData[] = [
  { name: "Warszawa", coordinates: [21.01, 52.23], listings: 5200, medianPrice: 16200, change30d: 3.5, voivodeship: "mazowieckie", medianRent: 4200 },
  { name: "Kraków", coordinates: [19.94, 50.06], listings: 3100, medianPrice: 13400, change30d: 2.4, voivodeship: "malopolskie", medianRent: 3400 },
  { name: "Wrocław", coordinates: [17.04, 51.11], listings: 2800, medianPrice: 11500, change30d: 1.9, voivodeship: "dolnoslaskie", medianRent: 2900 },
  { name: "Gdańsk", coordinates: [18.65, 54.35], listings: 2400, medianPrice: 13200, change30d: 2.9, voivodeship: "pomorskie", medianRent: 3500 },
  { name: "Poznań", coordinates: [16.93, 52.41], listings: 2200, medianPrice: 10800, change30d: 1.6, voivodeship: "wielkopolskie", medianRent: 2600 },
  { name: "Łódź", coordinates: [19.46, 51.77], listings: 1900, medianPrice: 7500, change30d: 0.9, voivodeship: "lodzkie", medianRent: 2000 },
  { name: "Katowice", coordinates: [19.02, 50.26], listings: 1700, medianPrice: 7800, change30d: -0.3, voivodeship: "slaskie", medianRent: 2100 },
  { name: "Szczecin", coordinates: [14.55, 53.43], listings: 1500, medianPrice: 8200, change30d: 1.3, voivodeship: "zachodniopomorskie", medianRent: 2200 },
  { name: "Lublin", coordinates: [22.57, 51.25], listings: 1300, medianPrice: 7200, change30d: 0.5, voivodeship: "lubelskie", medianRent: 1800 },
  { name: "Bydgoszcz", coordinates: [18.0, 53.12], listings: 1100, medianPrice: 7000, change30d: 1.1, voivodeship: "kujawsko_pomorskie", medianRent: 1750 },
  { name: "Białystok", coordinates: [23.15, 53.13], listings: 900, medianPrice: 6800, change30d: 0.4, voivodeship: "podlaskie", medianRent: 1700 },
  { name: "Rzeszów", coordinates: [22.0, 50.04], listings: 850, medianPrice: 7100, change30d: 0.8, voivodeship: "podkarpackie", medianRent: 1800 },
  { name: "Toruń", coordinates: [18.6, 53.01], listings: 800, medianPrice: 6900, change30d: 0.6, voivodeship: "kujawsko_pomorskie", medianRent: 1650 },
  { name: "Olsztyn", coordinates: [20.48, 53.78], listings: 750, medianPrice: 6500, change30d: 0.7, voivodeship: "warminsko_mazurskie", medianRent: 1600 },
  { name: "Kielce", coordinates: [20.63, 50.87], listings: 650, medianPrice: 6000, change30d: -0.2, voivodeship: "swietokrzyskie", medianRent: 1450 },
  { name: "Opole", coordinates: [17.93, 50.67], listings: 550, medianPrice: 6200, change30d: 0.2, voivodeship: "opolskie", medianRent: 1500 },
  { name: "Gorzów Wlkp.", coordinates: [15.23, 52.73], listings: 450, medianPrice: 5800, change30d: 0.5, voivodeship: "lubuskie", medianRent: 1400 },
  { name: "Zielona Góra", coordinates: [15.51, 51.94], listings: 480, medianPrice: 6100, change30d: 0.9, voivodeship: "lubuskie", medianRent: 1500 },
  { name: "Gdynia", coordinates: [18.54, 54.52], listings: 1200, medianPrice: 12800, change30d: 2.7, voivodeship: "pomorskie", medianRent: 3300 },
  { name: "Sopot", coordinates: [18.56, 54.44], listings: 400, medianPrice: 18500, change30d: 1.8, voivodeship: "pomorskie", medianRent: 4800 },
];

// ===== GeoJSON Generation =====

function generatePolygon(
  center: [number, number],
  radius: number,
  seed: number,
  points: number = 10
): [number, number][] {
  const coords: [number, number][] = [];
  for (let i = 0; i < points; i++) {
    const angle = (i / points) * Math.PI * 2 - Math.PI / 2;
    const noise = Math.sin(seed * 13.37 + i * 7.19) * 0.2 + 1;
    const r = radius * noise;
    coords.push([
      parseFloat((center[0] + Math.cos(angle) * r * 1.25).toFixed(3)),
      parseFloat((center[1] + Math.sin(angle) * r * 0.8).toFixed(3)),
    ]);
  }
  coords.push(coords[0]);
  return coords;
}

export function getVoivodeshipGeoJSON() {
  return {
    type: "FeatureCollection" as const,
    features: voivodeships.map((v, idx) => ({
      type: "Feature" as const,
      properties: {
        id: v.id,
        name: v.name,
        medianPrice: v.medianPrice,
        avgPrice: v.avgPrice,
        listings: v.listings,
        change30d: v.change30d,
        volatility: v.volatility,
        yieldEstimate: v.yieldEstimate,
        riskScore: v.riskScore,
        medianRent: v.medianRent,
        newListings7d: v.newListings7d,
        removedListings7d: v.removedListings7d,
      },
      geometry: {
        type: "Polygon" as const,
        coordinates: [generatePolygon(v.center, v.radius, idx)],
      },
    })),
  };
}

// ===== Time Series =====

export function generateTimeSeries(days: number = 90): TimeSeriesPoint[] {
  const data: TimeSeriesPoint[] = [];
  const now = new Date();
  const basePrice = 10200;
  const baseListings = 42000;

  for (let i = days; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);

    const dayIndex = days - i;
    const trend = dayIndex * 18;
    const seasonal = Math.sin(dayIndex * 0.08) * 350;
    const noise = Math.sin(dayIndex * 1.7) * 120 + Math.cos(dayIndex * 2.3) * 80;
    const medianPrice = Math.round(basePrice + trend + seasonal + noise);

    const listingsTrend = Math.sin(dayIndex * 0.05) * 3500;
    const listingsNoise = Math.sin(dayIndex * 1.2) * 800;

    data.push({
      date: date.toISOString().split("T")[0],
      medianPrice,
      avgPrice: Math.round(medianPrice * 1.085),
      p25: Math.round(medianPrice * 0.78),
      p75: Math.round(medianPrice * 1.28),
      activeListings: Math.round(baseListings + listingsTrend + listingsNoise),
      newListings: Math.round(620 + Math.sin(dayIndex * 0.4) * 180 + Math.sin(dayIndex * 1.1) * 60),
      removedListings: Math.round(540 + Math.cos(dayIndex * 0.35) * 150 + Math.cos(dayIndex * 0.9) * 50),
      priceChangePct: parseFloat(
        (Math.sin(dayIndex * 0.12) * 1.8 + Math.sin(dayIndex * 0.5) * 0.4).toFixed(2)
      ),
    });
  }

  return data;
}

// ===== Price Distribution =====

export const priceDistributionSale: PriceBucket[] = [
  { range: "< 5K", count: 980, percentage: 3.4, minPrice: 0 },
  { range: "5-6K", count: 2100, percentage: 7.3, minPrice: 5000 },
  { range: "6-7K", count: 3400, percentage: 11.9, minPrice: 6000 },
  { range: "7-8K", count: 4800, percentage: 16.8, minPrice: 7000 },
  { range: "8-9K", count: 5200, percentage: 18.2, minPrice: 8000 },
  { range: "9-10K", count: 4100, percentage: 14.3, minPrice: 9000 },
  { range: "10-12K", count: 3600, percentage: 12.6, minPrice: 10000 },
  { range: "12-14K", count: 2200, percentage: 7.7, minPrice: 12000 },
  { range: "14-16K", count: 1200, percentage: 4.2, minPrice: 14000 },
  { range: "> 16K", count: 1020, percentage: 3.6, minPrice: 16000 },
];

export const priceDistributionRent: PriceBucket[] = [
  { range: "< 1.5K", count: 1400, percentage: 8.2, minPrice: 0 },
  { range: "1.5-2K", count: 3200, percentage: 18.8, minPrice: 1500 },
  { range: "2-2.5K", count: 3800, percentage: 22.3, minPrice: 2000 },
  { range: "2.5-3K", count: 3100, percentage: 18.2, minPrice: 2500 },
  { range: "3-3.5K", count: 2200, percentage: 12.9, minPrice: 3000 },
  { range: "3.5-4K", count: 1500, percentage: 8.8, minPrice: 3500 },
  { range: "4-5K", count: 1100, percentage: 6.5, minPrice: 4000 },
  { range: "> 5K", count: 720, percentage: 4.2, minPrice: 5000 },
];

// ===== Rankings =====

export function getRankings(dealType: "sale" | "rent"): RankingEntry[] {
  return voivodeships
    .map((v) => ({
      region: v.name,
      medianPrice: dealType === "sale" ? v.medianPrice : v.medianRent,
      change30d: v.change30d,
      listings: v.listings,
      volatility: v.volatility,
      yield: v.yieldEstimate,
    }))
    .sort((a, b) => b.change30d - a.change30d);
}

// ===== Aggregate KPIs =====

export function getKPIs(dealType: "sale" | "rent") {
  const totalListings = voivodeships.reduce((s, v) => s + v.listings, 0);
  const totalNew7d = voivodeships.reduce((s, v) => s + v.newListings7d, 0);
  const totalRemoved7d = voivodeships.reduce((s, v) => s + v.removedListings7d, 0);
  const avgMedianPrice =
    dealType === "sale"
      ? Math.round(voivodeships.reduce((s, v) => s + v.medianPrice, 0) / voivodeships.length)
      : Math.round(voivodeships.reduce((s, v) => s + v.medianRent, 0) / voivodeships.length);
  const avgChange =
    parseFloat(
      (voivodeships.reduce((s, v) => s + v.change30d, 0) / voivodeships.length).toFixed(1)
    );
  const avgYield =
    parseFloat(
      (voivodeships.reduce((s, v) => s + v.yieldEstimate, 0) / voivodeships.length).toFixed(1)
    );

  return {
    totalListings,
    totalNew7d,
    totalRemoved7d,
    avgMedianPrice,
    avgChange,
    avgYield,
  };
}

// ===== Chart Color Constants (hex for Recharts) =====

export const CHART_COLORS = {
  primary: "#2bb5a0",
  secondary: "#f59e0b",
  tertiary: "#818cf8",
  positive: "#34d399",
  negative: "#f87171",
  muted: "#475569",
  grid: "rgba(148, 163, 184, 0.06)",
  text: "#64748b",
  area: "rgba(43, 181, 160, 0.08)",
  areaBand: "rgba(43, 181, 160, 0.12)",
};
